﻿# BlueCG 帳號批次移動：開一個分頁、等網頁跑完、關掉，再換下一個

$Zu          = 3                                                           # 0置頂 1戰鬥 2生產 3倉庫 4販賣 5普通 6棄置
$AccountFile = "$PSScriptRoot\accounts.txt"
$WaitSec     = 1.5                                                         # 每個分頁停留秒數
$Port        = 9222
$UserDir     = "$env:LOCALAPPDATA\bluecg-chrome"
$ChromeExe   = "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"

# ---------------- 檢查 ----------------
if ($Zu -lt 0 -or $Zu -gt 6) { Write-Host "Zu 只能填 0-6，目前是 $Zu"; exit 1 }
if (-not (Test-Path -LiteralPath $AccountFile)) { Write-Host "找不到帳號檔：$AccountFile"; exit 1 }
if (-not (Test-Path -LiteralPath $ChromeExe))   { Write-Host "找不到 Chrome：$ChromeExe"; exit 1 }

$accounts = @(Get-Content -LiteralPath $AccountFile -Encoding UTF8 |
              ForEach-Object { $_.Trim() } |
              Where-Object { $_ -and -not $_.StartsWith('#') })
if ($accounts.Count -eq 0) { Write-Host "帳號檔是空的"; exit 1 }

# ---------------- 啟動遙控用的 Chrome ----------------
$base     = "http://127.0.0.1:$Port"
$firstRun = -not (Test-Path -LiteralPath $UserDir)
$alive    = $false
try { Invoke-RestMethod "$base/json/version" -TimeoutSec 2 | Out-Null; $alive = $true } catch {}

if (-not $alive) {
  Write-Host "啟動 Chrome（遙控設定檔：$UserDir）"
  Start-Process -FilePath $ChromeExe -ArgumentList @(
    "--remote-debugging-port=$Port",
    "--user-data-dir=$UserDir",
    '--no-first-run',
    '--no-default-browser-check',
    'about:blank')
  for ($i = 0; $i -lt 40 -and -not $alive; $i++) {
    Start-Sleep -Milliseconds 500
    try { Invoke-RestMethod "$base/json/version" -TimeoutSec 2 | Out-Null; $alive = $true } catch {}
  }
}
if (-not $alive) { Write-Host "Chrome 遙控介面沒起來（$base）"; exit 1 }

# 新設定檔沒有登入 cookie，不擋的話整批都會白跑
if ($firstRun) {
  Invoke-RestMethod -Method Put -Uri "$base/json/new?$([uri]::EscapeDataString('https://www.bluecg.net/'))" | Out-Null
  Read-Host "第一次使用：請在剛開的 Chrome 登入 bluecg.net（勾記住登入），好了按 Enter 繼續"
}

# ---------------- 逐一移動 ----------------
Write-Host ""
Write-Host "移動到目錄 zu=$Zu，共 $($accounts.Count) 個帳號"
$failed = @()
$n = 0
foreach ($acc in $accounts) {
  $n++
  $url = "https://www.bluecg.net/plugin.php?id=gift:array&ID=$acc&zu=$Zu"
  try {
    $tab = Invoke-RestMethod -Method Put -Uri "$base/json/new?$([uri]::EscapeDataString($url))"
    Start-Sleep -Milliseconds ([int]($WaitSec * 1000))
    Invoke-RestMethod "$base/json/close/$($tab.id)" | Out-Null
    Write-Host ("[{0}/{1}] {2}" -f $n, $accounts.Count, $acc)
  } catch {
    $failed += $acc
    Write-Host ("[{0}/{1}] {2}  失敗：{3}" -f $n, $accounts.Count, $acc, $_.Exception.Message)
  }
}

Write-Host ""
Write-Host "完成 $($accounts.Count - $failed.Count)/$($accounts.Count)"
if ($failed.Count -gt 0) { Write-Host ("失敗：" + ($failed -join ', ')) }
