@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0move-accounts.ps1"
pause
